package com.pet502.mascotas502gt.Datos;

public class Http {

    public static final String URL_WEB_SERVICE = "http://192.168.0.102:8080/Mascotas3/";

}
