package com.pet502.mascotas502gt;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

}